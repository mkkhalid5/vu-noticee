package com.FALCO.FLBrowser;

import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.sdsmdg.tastytoast.*;
import com.shashank.sony.fancytoastlib.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import java.util.ArrayList;
import android.speech.RecognizerIntent;


public class HomeActivity extends AppCompatActivity {
	
	private HashMap<String, Object> map = new HashMap<>();
	public static final int RESULT_SPEECH = 1;
	
	private ArrayList<HashMap<String, Object>> suggested_site = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> news = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private GridView gridview1;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private ImageView imageview1;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private ImageView imageview3;
	private TextView textview1;
	private ImageView imageview4;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private TextView textview2;
	private ImageView imageview5;
	private ImageView imageview6;
	private TextView textview3;
	private ImageView imageview7;
	private RecyclerView recyclerview1;
	
	private RequestNetwork req;
	private RequestNetwork.RequestListener _req_request_listener;
	private Intent intent = new Intent();
	private PopupWindow popUp;
	private AlertDialog.Builder dialog;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.home);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		gridview1 = findViewById(R.id.gridview1);
		linear11 = findViewById(R.id.linear11);
		linear12 = findViewById(R.id.linear12);
		imageview1 = findViewById(R.id.imageview1);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		imageview3 = findViewById(R.id.imageview3);
		textview1 = findViewById(R.id.textview1);
		imageview4 = findViewById(R.id.imageview4);
		linear7 = findViewById(R.id.linear7);
		linear8 = findViewById(R.id.linear8);
		linear9 = findViewById(R.id.linear9);
		textview2 = findViewById(R.id.textview2);
		imageview5 = findViewById(R.id.imageview5);
		imageview6 = findViewById(R.id.imageview6);
		textview3 = findViewById(R.id.textview3);
		imageview7 = findViewById(R.id.imageview7);
		recyclerview1 = findViewById(R.id.recyclerview1);
		req = new RequestNetwork(this);
		dialog = new AlertDialog.Builder(this);
		
		linear6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), SearchActivity.class);
				startActivity(intent);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
				finish();
			}
		});
		
		gridview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				intent.putExtra("url", suggested_site.get((int)_position).get("url").toString());
				intent.setClass(getApplicationContext(), WebActivity.class);
				startActivity(intent);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
				finish();
			}
		});
		
		linear4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				TastyToast.makeText(getApplicationContext(), "This function will be added soon!", TastyToast.LENGTH_LONG, TastyToast.ERROR);
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				View popup = getLayoutInflater().inflate(R.layout.popup_home, null);
				final PopupWindow pop_up = new PopupWindow(popup, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);
				final LinearLayout line1 = popup.findViewById(R.id.linear1);
				final LinearLayout line2 = popup.findViewById(R.id.linear2);
				final LinearLayout line3 = popup.findViewById(R.id.linear3);
				final LinearLayout line4 = popup.findViewById(R.id.linear4);
				final LinearLayout line5 = popup.findViewById(R.id.linear5);
				final LinearLayout line6 = popup.findViewById(R.id.linear6);
				final ImageView img1 = popup.findViewById(R.id.imageview1);
				final ImageView img2 = popup.findViewById(R.id.imageview2);
				final ImageView img3 = popup.findViewById(R.id.imageview3);
				//Design↓
				int[] colorsCRNIE = { Color.parseColor("#FFFFFF"), Color.parseColor("#FFFFFF") }; android.graphics.drawable.GradientDrawable CRNIE = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNIE);
				CRNIE.setCornerRadii(new float[]{(int)15,(int)15,(int)15,(int)15,(int)15,(int)15,(int)15,(int)15});
				CRNIE.setStroke((int) 0, Color.parseColor("#000000"));
				line1.setElevation((float) 7);
				line1.setBackground(CRNIE);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				int[] colorsCRNUG = { Color.parseColor("#E0E0E0"), Color.parseColor("#E0E0E0") }; android.graphics.drawable.GradientDrawable CRNUG = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNUG);
				CRNUG.setCornerRadii(new float[]{(int)15,(int)15,(int)15,(int)15,(int)0,(int)0,(int)0,(int)0});
				CRNUG.setStroke((int) 0, Color.parseColor("#000000"));
				line2.setElevation((float) 2);
				line2.setBackground(CRNUG);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				//Ripple effects↓
				_RippleEffects("#BDBDBD", img1);
				_RippleEffects("#BDBDBD", img2);
				//On click↓
				line4.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						intent.setClass(getApplicationContext(), HistoryActivity.class);
						startActivity(intent);
						overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
						finish();
					}
				});
				line6.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						intent.setClass(getApplicationContext(), CreditsActivity.class);
						startActivity(intent);
						overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
						finish();
					}
				});
				line5.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						TastyToast.makeText(getApplicationContext(), "This function will be added soon!", TastyToast.LENGTH_LONG, TastyToast.ERROR);
						pop_up.dismiss();
					}
				});
				line3.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						intent.setAction(Intent.ACTION_VIEW);
						intent.setData(Uri.parse("https://web.sketchub.in/u/FALCO"));
						startActivity(intent);
					}
				});
				img1.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						pop_up.dismiss();
					}
				});
				img2.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						SketchwareUtil.showMessage(getApplicationContext(), "soon!");
					}
				});
				img3.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						
					}
				});
				pop_up.showAsDropDown(_view, 0,0);
			}
		});
		
		linear9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
				                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
				                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US");
				                try {
					                    startActivityForResult(intent, RESULT_SPEECH);
					
					                } catch (ActivityNotFoundException e) {
					                    
					                }
			}
		});
		
		_req_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				try{
					
					JSONObject response = new JSONObject(_response);
					JSONArray jsonArray=response.getJSONArray("articles");
					for (int i=0;i<jsonArray.length();i++){
							
							JSONObject jsonObject=jsonArray.getJSONObject(i);
							String title=jsonObject.getString("title");
							String url=jsonObject.getString("url");
						String urlToImage=jsonObject.getString("urlToImage");
						String author=jsonObject.getString("author");
						String date=jsonObject.getString("publishedAt");
						map = new HashMap<>();
						map.put("title", title);
						map.put("url", url);
						map.put("author", author);
						map.put("imageUrl", urlToImage);
						map.put("date", date);
						news.add(map);
						recyclerview1.setAdapter(new Recyclerview1Adapter(news));
					}
				}catch(JSONException e){
					showMessage(e.toString());
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				TastyToast.makeText(getApplicationContext(), "Check your network connection!", TastyToast.LENGTH_LONG, TastyToast.ERROR);
			}
		};
	}
	
	private void initializeLogic() {
		_StatusBar_Change_TextColor(linear1, "#F3F6FB");
		_RippleEffects("#BDBDBD", imageview3);
		_RippleEffects("#BDBDBD", linear9);
		_RippleEffects("#BDBDBD", linear4);
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/productsansregular.ttf"), 0);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/opensansmedium.ttf"), 0);
		int[] colorsCRNIG = { Color.parseColor("#D2DEF6"), Color.parseColor("#D2DEF6") }; android.graphics.drawable.GradientDrawable CRNIG = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNIG);
		CRNIG.setCornerRadii(new float[]{(int)360,(int)360,(int)360,(int)360,(int)360,(int)360,(int)360,(int)360});
		CRNIG.setStroke((int) 0, Color.parseColor("#000000"));
		linear6.setElevation((float) 0);
		linear6.setBackground(CRNIG);
		
		//Paste this code in (add source directly block) asd block
		//Milz
		recyclerview1.setLayoutManager(new LinearLayoutManager(this));
		req.startRequestNetwork(RequestNetworkController.GET, "https://newsapi.org/v2/top-headlines?sources=techcrunch&apiKey=4d1ad9cc776843e4a2af8b647fb3f788", "A", _req_request_listener);
		try{
			java.io.InputStream inputstream1 = getAssets().open("website's.json");
			suggested_site = new Gson().fromJson(SketchwareUtil.copyFromInputStream(inputstream1), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			gridview1.setAdapter(new Gridview1Adapter(suggested_site));
		}catch(Exception e){
			 
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		switch (_requestCode){
				            case RESULT_SPEECH:
				                if(_resultCode == RESULT_OK && _data != null){
						                    ArrayList<String> text = _data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
						                                
						
						intent.putExtra("quarry", text.get(0));
						intent.setClass(getApplicationContext(), SearchActivity.class);
						startActivity(intent);
						overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
						finish();
						                    
						                }
				                break;
				        }
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	
	@Override
	public void onBackPressed() {
		dialog.setTitle("Exit?");
		dialog.setMessage("Do you want to exit?");
		dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				finishAffinity();
			}
		});
		dialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				
			}
		});
		
		{
			final AlertDialog alert = dialog.show();
			DisplayMetrics screen = new DisplayMetrics();
			getWindowManager().getDefaultDisplay().getMetrics(screen);
			double dp = 27;
			double logicalDensity = screen.density;
			int px = (int) Math.ceil(dp * logicalDensity);
			alert.getWindow().getDecorView().setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)px, Color.parseColor("#FFFFFF")));
				alert.getWindow().getDecorView().setPadding(8,8,8,8);
			alert.show();
			
			alert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.parseColor("#2196f3"));
				alert.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.parseColor("#2196f3"));
				alert.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(Color.parseColor("#2196f3"));
			alert.getButton(AlertDialog.BUTTON_POSITIVE).setAllCaps(false);
			alert.getButton(AlertDialog.BUTTON_NEGATIVE).setAllCaps(false);
			alert.getButton(AlertDialog.BUTTON_NEUTRAL).setAllCaps(false);
			TextView textT = (TextView)alert.getWindow().getDecorView().findViewById(android.R.id.message);
			textT.setTextColor(Color.parseColor("#000000"));
			
			int titleId = getResources().getIdentifier( "alertTitle", "id", "android" ); 
			
			if (titleId > 0) { 
					     TextView dialogTitle = (TextView) alert.getWindow().getDecorView().findViewById(titleId); 
				         
					     if (dialogTitle != null) {
						     	     dialogTitle.setTextColor(Color.parseColor("#000000"));
						     } 
			}}
	}
	public void _StatusBar_Change_TextColor(final View _linear, final String _color) {
		try{
			
			_linear.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
			Window w = this.getWindow();w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(Color.parseColor(_color));
			
		}catch (Exception ex) {
			
		}finally{
			
		}
	}
	
	
	public void _suggested_sites() {
		
	}
	
	
	public void _RippleEffects(final String _color, final View _view) {
		android.content.res.ColorStateList clr = new android.content.res.ColorStateList(new int[][]{new int[]{}},new int[]{Color.parseColor(_color)});
		android.graphics.drawable.RippleDrawable ripdr = new android.graphics.drawable.RippleDrawable(clr, null, null);
		_view.setBackground(ripdr);
	}
	
	public class Gridview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Gridview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.suggested_sites, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			
			int[] colorsCRNMR = { Color.parseColor("#ffffff"), Color.parseColor("#ffffff") }; android.graphics.drawable.GradientDrawable CRNMR = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNMR);
			CRNMR.setCornerRadii(new float[]{(int)20,(int)20,(int)20,(int)20,(int)20,(int)20,(int)20,(int)20});
			CRNMR.setStroke((int) 0, Color.parseColor("#000000"));
			linear1.setElevation((float) 2);
			linear1.setBackground(CRNMR);
			
			//Paste this code in (add source directly block) asd block
			//Milz
			Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("icon_url").toString())).into(imageview1);
			
			return _view;
		}
	}
	
	public class Recyclerview1Adapter extends RecyclerView.Adapter<Recyclerview1Adapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.news, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final ImageView banner = _view.findViewById(R.id.banner);
			final TextView title = _view.findViewById(R.id.title);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			final TextView author = _view.findViewById(R.id.author);
			final TextView textview4 = _view.findViewById(R.id.textview4);
			final TextView date = _view.findViewById(R.id.date);
			
			int[] colorsCRNBR = { Color.parseColor("#FFFFFF"), Color.parseColor("#FFFFFF") }; android.graphics.drawable.GradientDrawable CRNBR = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNBR);
			CRNBR.setCornerRadii(new float[]{(int)31,(int)31,(int)31,(int)31,(int)31,(int)31,(int)31,(int)31});
			CRNBR.setStroke((int) 0, Color.parseColor("#000000"));
			linear2.setElevation((float) 0);
			linear2.setBackground(CRNBR);
			
			//Paste this code in (add source directly block) asd block
			//Milz
			Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("imageUrl").toString())).into(banner);
			title.setText(_data.get((int)_position).get("title").toString());
			author.setText(_data.get((int)_position).get("author").toString());
			date.setText(_data.get((int)_position).get("date").toString());
			title.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/productsansregular.ttf"), 0);
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					intent.putExtra("url", _data.get((int)_position).get("url").toString());
					intent.setClass(getApplicationContext(), WebActivity.class);
					startActivity(intent);
					overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
					finish();
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}