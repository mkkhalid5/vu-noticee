package com.FALCO.FLBrowser;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.sdsmdg.tastytoast.*;
import com.shashank.sony.fancytoastlib.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class CreditsActivity extends AppCompatActivity {
	
	private ArrayList<HashMap<String, Object>> main_list = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> design_list = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear4;
	private ImageView imageview1;
	private LinearLayout linear3;
	private TextView textview1;
	private LinearLayout linear6;
	private ListView listview1;
	
	private Intent intent = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.credits);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear4 = findViewById(R.id.linear4);
		imageview1 = findViewById(R.id.imageview1);
		linear3 = findViewById(R.id.linear3);
		textview1 = findViewById(R.id.textview1);
		linear6 = findViewById(R.id.linear6);
		listview1 = findViewById(R.id.listview1);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), HomeActivity.class);
				startActivity(intent);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
				finish();
			}
		});
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (_position == 0) {
					intent.setAction(Intent.ACTION_VIEW);
					intent.setData(Uri.parse("https://web.sketchub.in/u/FALCO"));
					startActivity(intent);
				}
				if (_position == 1) {
					intent.setAction(Intent.ACTION_VIEW);
					intent.setData(Uri.parse("https://play.google.com/store/apps/details?id=com.crn.korner"));
					startActivity(intent);
				}
				if (_position == 2) {
					intent.setAction(Intent.ACTION_VIEW);
					intent.setData(Uri.parse("https://web.sketchub.in/p/14964"));
					startActivity(intent);
				}
				if (_position == 3) {
					intent.setAction(Intent.ACTION_VIEW);
					intent.setData(Uri.parse("https://youtube.com/@ashishtechnozone5567?si=VnqBqRFuZxChGTzD"));
					startActivity(intent);
				}
				if (_position == 4) {
					intent.setAction(Intent.ACTION_VIEW);
					intent.setData(Uri.parse("https://web.sketchub.in/u/INXINC"));
					startActivity(intent);
				}
				if (_position == 5) {
					intent.setAction(Intent.ACTION_VIEW);
					intent.setData(Uri.parse("https://web.sketchub.in/u/ArabWare"));
					startActivity(intent);
				}
			}
		});
	}
	
	private void initializeLogic() {
		_StatusBar_Change_TextColor(linear1, "#FFFFFF");
		linear2.setElevation((float) 5);
		int[] colorsCRNWQ = { Color.parseColor("#ffffff"), Color.parseColor("#ffffff") }; android.graphics.drawable.GradientDrawable CRNWQ = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNWQ);
		CRNWQ.setCornerRadii(new float[]{(int)27,(int)27,(int)27,(int)27,(int)27,(int)27,(int)27,(int)27});
		CRNWQ.setStroke((int) 0, Color.parseColor("#000000"));
		linear6.setElevation((float) 5);
		linear6.setBackground(CRNWQ);
		
		//Paste this code in (add source directly block) asd block
		//Milz
		_RippleEffect("#BDBDBD", imageview1);
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/productsansregular.ttf"), 0);
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("A", "B");
			main_list.add(_item);
		}
		
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("C", "D");
			main_list.add(_item);
		}
		
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("E", "F");
			main_list.add(_item);
		}
		
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("G", "H");
			main_list.add(_item);
		}
		
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("I", "J");
			main_list.add(_item);
		}
		
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("K", "L");
			main_list.add(_item);
		}
		
		listview1.setAdapter(new Listview1Adapter(main_list));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
	}
	
	@Override
	public void onBackPressed() {
		intent.setClass(getApplicationContext(), HomeActivity.class);
		startActivity(intent);
		overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
		finish();
	}
	public void _StatusBar_Change_TextColor(final View _linear, final String _color) {
		try{
			
			_linear.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
			Window w = this.getWindow();w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(Color.parseColor(_color));
			
		}catch (Exception ex) {
			
		}finally{
			
		}
	}
	
	
	public void _RippleEffect(final String _color, final View _view) {
		android.content.res.ColorStateList clr = new android.content.res.ColorStateList(new int[][]{new int[]{}},new int[]{Color.parseColor(_color)});
		android.graphics.drawable.RippleDrawable ripdr = new android.graphics.drawable.RippleDrawable(clr, null, null);
		_view.setBackground(ripdr);
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.credits_item, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			
			textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/productsansregular.ttf"), 0);
			if (_position == 0) {
				textview1.setText("FALCO");
				imageview1.setImageResource(R.drawable.falco);
			}
			if (_position == 1) {
				textview1.setText("Radii");
				imageview1.setImageResource(R.drawable.radii);
			}
			if (_position == 2) {
				textview1.setText("App Designer");
				imageview1.setImageResource(R.drawable.app_desinger);
			}
			if (_position == 3) {
				textview1.setText("Ashish Techno Zone");
				imageview1.setImageResource(R.drawable.ashish_techno_zone);
			}
			if (_position == 4) {
				textview1.setText("INXINC");
				imageview1.setImageResource(R.drawable.inxinc_arabware_1);
			}
			if (_position == 5) {
				textview1.setText("Arabware");
				imageview1.setImageResource(R.drawable.inxinc_arabware_2);
			}
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}