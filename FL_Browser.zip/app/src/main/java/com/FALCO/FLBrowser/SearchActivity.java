package com.FALCO.FLBrowser;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.sdsmdg.tastytoast.*;
import com.shashank.sony.fancytoastlib.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import java.util.ArrayList;
import android.speech.RecognizerIntent;


public class SearchActivity extends AppCompatActivity {
	
	private String json = "";
	private double num = 0;
	private HashMap<String, Object> historyMap = new HashMap<>();
	public static final int RESULT_SPEECH = 1;
	
	private ArrayList<HashMap<String, Object>> listMap = new ArrayList<>();
	private ArrayList<String> listString = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> history = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private ImageView imageview1;
	private EditText edittext1;
	private ImageView imageview2;
	private ImageView imageview3;
	private ListView listview1;
	private ListView listview2;
	
	private RequestNetwork req;
	private RequestNetwork.RequestListener _req_request_listener;
	private Intent intent = new Intent();
	private AlertDialog.Builder dialog;
	private SharedPreferences sp;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.search);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		imageview1 = findViewById(R.id.imageview1);
		edittext1 = findViewById(R.id.edittext1);
		imageview2 = findViewById(R.id.imageview2);
		imageview3 = findViewById(R.id.imageview3);
		listview1 = findViewById(R.id.listview1);
		listview2 = findViewById(R.id.listview2);
		req = new RequestNetwork(this);
		dialog = new AlertDialog.Builder(this);
		sp = getSharedPreferences("history", Activity.MODE_PRIVATE);
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (_charSeq.equals("")) {
					listview2.setVisibility(View.VISIBLE);
					listview1.setVisibility(View.GONE);
				}
				else {
					listview2.setVisibility(View.GONE);
					listview1.setVisibility(View.VISIBLE);
					req.startRequestNetwork(RequestNetworkController.GET, "http://suggestqueries.google.com/complete/search?client=chrome&q=".concat(_charSeq.concat("&client=firefox&en")), "A", _req_request_listener);
					if (listMap.size() == 0) {
						{
							HashMap<String, Object> _item = new HashMap<>();
							_item.put("suggestion", edittext1.getText().toString());
							listMap.add(_item);
						}
						
						listview1.setAdapter(new Listview1Adapter(listMap));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					}
					listMap.clear();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				historyMap = new HashMap<>();
				historyMap.put("search_history", edittext1.getText().toString());
				history.add(historyMap);
				sp.edit().putString("search_history", new Gson().toJson(history)).commit();
				intent.putExtra("quarry", edittext1.getText().toString());
				intent.setClass(getApplicationContext(), WebActivity.class);
				startActivity(intent);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
				finish();
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
				                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
				                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US");
				                try {
					                    startActivityForResult(intent, RESULT_SPEECH);
					
					                } catch (ActivityNotFoundException e) {
					                    
					                }
			}
		});
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				historyMap = new HashMap<>();
				historyMap.put("search_history", listMap.get((int)_position).get("suggestion").toString());
				history.add(historyMap);
				sp.edit().putString("search_history", new Gson().toJson(history)).commit();
				intent.putExtra("quarry", listMap.get((int)_position).get("suggestion").toString());
				intent.setClass(getApplicationContext(), WebActivity.class);
				startActivity(intent);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
				finish();
			}
		});
		
		listview2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				intent.putExtra("quarry", history.get((int)_position).get("search_history").toString());
				intent.setClass(getApplicationContext(), WebActivity.class);
				startActivity(intent);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
				finish();
			}
		});
		
		listview2.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				dialog.setTitle(history.get((int)_position).get("search_history").toString());
				dialog.setMessage("Delete from search history?");
				dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						history.remove((int)(_position));
						sp.edit().putString("search_history", new Gson().toJson(history)).commit();
						listview2.setAdapter(new Listview2Adapter(history));
						((BaseAdapter)listview2.getAdapter()).notifyDataSetChanged();
					}
				});
				dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				{
					final AlertDialog alert = dialog.show();
					DisplayMetrics screen = new DisplayMetrics();
					getWindowManager().getDefaultDisplay().getMetrics(screen);
					double dp = 30;
					double logicalDensity = screen.density;
					int px = (int) Math.ceil(dp * logicalDensity);
					alert.getWindow().getDecorView().setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)px, Color.parseColor("#FFFFFF")));
						alert.getWindow().getDecorView().setPadding(8,8,8,8);
					alert.show();
					
					alert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.parseColor("#0098FC"));
						alert.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.parseColor("#0098FC"));
						alert.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(Color.parseColor("#2196f3"));
					alert.getButton(AlertDialog.BUTTON_POSITIVE).setAllCaps(false);
					alert.getButton(AlertDialog.BUTTON_NEGATIVE).setAllCaps(false);
					alert.getButton(AlertDialog.BUTTON_NEUTRAL).setAllCaps(false);
					TextView textT = (TextView)alert.getWindow().getDecorView().findViewById(android.R.id.message);
					textT.setTextColor(Color.parseColor("#19354C"));
					
					int titleId = getResources().getIdentifier( "alertTitle", "id", "android" ); 
					
					if (titleId > 0) { 
							     TextView dialogTitle = (TextView) alert.getWindow().getDecorView().findViewById(titleId); 
						         
							     if (dialogTitle != null) {
								     	     dialogTitle.setTextColor(Color.parseColor("#000000"));
								     } 
					}}
				return true;
			}
		});
		
		_req_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				json = _response.substring((int)(0), (int)(Double.parseDouble(String.valueOf((long)(_response.lastIndexOf(",[],"))).replace("-1", "0")))).replace("\",[\"", "\",\"");
				if (json.equals("")) {
					listString = new Gson().fromJson("[]", new TypeToken<ArrayList<String>>(){}.getType());
					{
						HashMap<String, Object> _item = new HashMap<>();
						_item.put("suggestion", edittext1.getText().toString());
						listMap.add(_item);
					}
					
					listview1.setAdapter(new Listview1Adapter(listMap));
					((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
				}
				else {
					listString = new Gson().fromJson(json, new TypeToken<ArrayList<String>>(){}.getType());
					for(int _repeat27 = 0; _repeat27 < (int)(Double.parseDouble(String.valueOf((long)(1 - listString.size())).replace("-", ""))); _repeat27++) {
						num++;
						{
							HashMap<String, Object> _item = new HashMap<>();
							_item.put("suggestion", listString.get((int)(num)));
							listMap.add(_item);
						}
						
						listview1.setAdapter(new Listview1Adapter(listMap));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					}
				}
				num = 0;
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), "Network error!");
			}
		};
	}
	
	private void initializeLogic() {
		_StatusBar_Change_TextColor(linear1, "#F3F6FB");
		int[] colorsCRNYD = { Color.parseColor("#ffffff"), Color.parseColor("#ffffff") }; android.graphics.drawable.GradientDrawable CRNYD = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNYD);
		CRNYD.setCornerRadii(new float[]{(int)33,(int)33,(int)33,(int)33,(int)33,(int)33,(int)33,(int)33});
		CRNYD.setStroke((int) 0, Color.parseColor("#000000"));
		linear3.setElevation((float) 0);
		linear3.setBackground(CRNYD);
		
		//Paste this code in (add source directly block) asd block
		//Milz
		int[] colorsCRNDK = { Color.parseColor("#ffffff"), Color.parseColor("#ffffff") }; android.graphics.drawable.GradientDrawable CRNDK = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNDK);
		CRNDK.setCornerRadii(new float[]{(int)33,(int)33,(int)33,(int)33,(int)33,(int)33,(int)33,(int)33});
		CRNDK.setStroke((int) 0, Color.parseColor("#000000"));
		linear2.setElevation((float) 0);
		linear2.setBackground(CRNDK);
		
		//Paste this code in (add source directly block) asd block
		//Milz
		_RippleEffect("#BDBDBD", imageview2);
		_RippleEffect("#BDBDBD", imageview3);
		edittext1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/productsansregular.ttf"), 0);
		if (sp.getString("search_history", "").equals("")) {
			linear3.setVisibility(View.GONE);
		}
		else {
			history = new Gson().fromJson(sp.getString("search_history", ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			Collections.reverse(history);
			listview2.setAdapter(new Listview2Adapter(history));
			((BaseAdapter)listview2.getAdapter()).notifyDataSetChanged();
		}
		if (getIntent().hasExtra("url")) {
			edittext1.setText(getIntent().getStringExtra("url"));
		}
		if (getIntent().hasExtra("quarry")) {
			edittext1.setText(getIntent().getStringExtra("quarry"));
		}
		listview1.setVisibility(View.GONE);
		edittext1.setOnEditorActionListener(new TextView.OnEditorActionListener() {
				@Override public boolean onEditorAction(TextView v, int actionId, KeyEvent event) { 
						if(actionId == 3){
					
					historyMap = new HashMap<>();
					historyMap.put("search_history", edittext1.getText().toString());
					history.add(historyMap);
					sp.edit().putString("search_history", new Gson().toJson(history)).commit();
					intent.putExtra("quarry", edittext1.getText().toString());
					intent.setClass(getApplicationContext(), WebActivity.class);
					startActivity(intent);
					overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
					
								 } 
						return false;
						 }
				 });
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		switch (_requestCode){
				            case RESULT_SPEECH:
				                if(_resultCode == RESULT_OK && _data != null){
						                    ArrayList<String> text = _data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
						                                
						
						edittext1.setText(text.get(0));
						                    
						                }
				                break;
				        }
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		intent.setClass(getApplicationContext(), HomeActivity.class);
		startActivity(intent);
		overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
		finish();
	}
	
	public void _RippleEffect(final String _color, final View _view) {
		android.content.res.ColorStateList clr = new android.content.res.ColorStateList(new int[][]{new int[]{}},new int[]{Color.parseColor(_color)});
		android.graphics.drawable.RippleDrawable ripdr = new android.graphics.drawable.RippleDrawable(clr, null, null);
		_view.setBackground(ripdr);
	}
	
	
	public void _StatusBar_Change_TextColor(final View _linear, final String _color) {
		try{
			
			_linear.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
			Window w = this.getWindow();w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(Color.parseColor(_color));
			
		}catch (Exception ex) {
			
		}finally{
			
		}
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.suggestions, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			
			_RippleEffect("#EEEEEE", imageview2);
			textview1.setText(_data.get((int)_position).get("suggestion").toString());
			textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/opensansmedium.ttf"), 0);
			imageview2.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					edittext1.setText(_data.get((int)_position).get("suggestion").toString());
				}
			});
			
			return _view;
		}
	}
	
	public class Listview2Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview2Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.suggestions, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			
			_RippleEffect("#EEEEEE", imageview2);
			textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/opensansmedium.ttf"), 0);
			imageview1.setImageResource(R.drawable.ic_restore_black);
			textview1.setText(_data.get((int)_position).get("search_history").toString());
			imageview2.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					edittext1.setText(_data.get((int)_position).get("search_history").toString());
				}
			});
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}