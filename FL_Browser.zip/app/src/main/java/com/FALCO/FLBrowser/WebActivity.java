package com.FALCO.FLBrowser;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.sdsmdg.tastytoast.*;
import com.shashank.sony.fancytoastlib.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class WebActivity extends AppCompatActivity {
	
	private String searchFor = "";
	private HashMap<String, Object> map = new HashMap<>();
	private String domain = "";
	private String url = "";
	private boolean desktop_site = false;
	
	private ArrayList<HashMap<String, Object>> history = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private ProgressBar progressBar;
	private SwipeRefreshLayout swiperefreshlayout1;
	private ImageView imageview1;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private ImageView imageview3;
	private ImageView imageview4;
	private TextView textview2;
	private TextView textview1;
	private ScrollView vscroll1;
	private LinearLayout linear5;
	private WebView webview1;
	private LinearLayout linear6;
	private LinearLayout linear8;
	private LinearLayout linear11;
	private ImageView imageview5;
	private LinearLayout linear9;
	private TextView textview3;
	private TextView textview4;
	private LinearLayout linear10;
	private TextView textview6;
	private TextView textview5;
	private TextView textview7;
	private TextView textview8;
	private TextView textview9;
	private TextView textview10;
	
	private Intent intent = new Intent();
	private SharedPreferences sp;
	private SharedPreferences data;
	private RequestNetwork req;
	private RequestNetwork.RequestListener _req_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.web);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		progressBar = findViewById(R.id.progressBar);
		swiperefreshlayout1 = findViewById(R.id.swiperefreshlayout1);
		imageview1 = findViewById(R.id.imageview1);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		imageview3 = findViewById(R.id.imageview3);
		imageview4 = findViewById(R.id.imageview4);
		textview2 = findViewById(R.id.textview2);
		textview1 = findViewById(R.id.textview1);
		vscroll1 = findViewById(R.id.vscroll1);
		linear5 = findViewById(R.id.linear5);
		webview1 = findViewById(R.id.webview1);
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setSupportZoom(true);
		linear6 = findViewById(R.id.linear6);
		linear8 = findViewById(R.id.linear8);
		linear11 = findViewById(R.id.linear11);
		imageview5 = findViewById(R.id.imageview5);
		linear9 = findViewById(R.id.linear9);
		textview3 = findViewById(R.id.textview3);
		textview4 = findViewById(R.id.textview4);
		linear10 = findViewById(R.id.linear10);
		textview6 = findViewById(R.id.textview6);
		textview5 = findViewById(R.id.textview5);
		textview7 = findViewById(R.id.textview7);
		textview8 = findViewById(R.id.textview8);
		textview9 = findViewById(R.id.textview9);
		textview10 = findViewById(R.id.textview10);
		sp = getSharedPreferences("history", Activity.MODE_PRIVATE);
		data = getSharedPreferences("data", Activity.MODE_PRIVATE);
		req = new RequestNetwork(this);
		
		swiperefreshlayout1.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
			@Override
			public void onRefresh() {
				req.startRequestNetwork(RequestNetworkController.GET, "https://www.google.com/", "A", _req_request_listener);
				webview1.loadUrl(webview1.getUrl());
				webview1.clearCache(true);
				swiperefreshlayout1.setRefreshing(false);
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), HomeActivity.class);
				startActivity(intent);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
				finish();
			}
		});
		
		linear3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.putExtra("url", webview1.getUrl());
				intent.setClass(getApplicationContext(), SearchActivity.class);
				startActivity(intent);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
			}
		});
		
		linear4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				View popup = getLayoutInflater().inflate(R.layout.poup_web, null);
				final PopupWindow pop_up = new PopupWindow(popup, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);
				final LinearLayout line1 = popup.findViewById(R.id.linear1);
				final LinearLayout line2 = popup.findViewById(R.id.linear2);
				final LinearLayout line4 = popup.findViewById(R.id.linear4);
				final LinearLayout line9 = popup.findViewById(R.id.linear9);
				final LinearLayout line10 = popup.findViewById(R.id.linear10);
				final LinearLayout line11 = popup.findViewById(R.id.linear11);
				final LinearLayout line6 = popup.findViewById(R.id.linear6);
				final LinearLayout line5 = popup.findViewById(R.id.linear5);
				final LinearLayout line8 = popup.findViewById(R.id.linear8);
				final ImageView img1 = popup.findViewById(R.id.imageview1);
				final ImageView img2 = popup.findViewById(R.id.imageview2);
				final ImageView img3 = popup.findViewById(R.id.imageview3);
				final CheckBox check1 = popup.findViewById(R.id.checkbox1);
				final CheckBox check2 = popup.findViewById(R.id.checkbox2);
				//Design↓
				int[] colorsCRNIE = { Color.parseColor("#FFFFFF"), Color.parseColor("#FFFFFF") }; android.graphics.drawable.GradientDrawable CRNIE = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNIE);
				CRNIE.setCornerRadii(new float[]{(int)15,(int)15,(int)15,(int)15,(int)15,(int)15,(int)15,(int)15});
				CRNIE.setStroke((int) 0, Color.parseColor("#000000"));
				line1.setElevation((float) 7);
				line1.setBackground(CRNIE);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				int[] colorsCRNUG = { Color.parseColor("#E0E0E0"), Color.parseColor("#E0E0E0") }; android.graphics.drawable.GradientDrawable CRNUG = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNUG);
				CRNUG.setCornerRadii(new float[]{(int)15,(int)15,(int)15,(int)15,(int)0,(int)0,(int)0,(int)0});
				CRNUG.setStroke((int) 0, Color.parseColor("#000000"));
				line2.setElevation((float) 2);
				line2.setBackground(CRNUG);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				_Checkbox_ChangeColor(check1, "#757575");
				_Checkbox_ChangeColor(check2, "#757575");
				//Ripple effects↓
				_RippleEffect("#E0E0E0", img1);
				_RippleEffect("#E0E0E0", img2);
				//On click↓
				check1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
									@Override
									public void onCheckedChanged(CompoundButton _param1, boolean _param2)  {
												final boolean _isChecked = _param2;
												if (_isChecked) {
															data.edit().putString("desktop", "true").commit();
															webview1.loadUrl(webview1.getUrl());
												}
												else {
															data.edit().putString("desktop", "false").commit();
															webview1.loadUrl(webview1.getUrl());
												}
									}
						});
				check2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
									@Override
									public void onCheckedChanged(CompoundButton _param1, boolean _param2)  {
												final boolean _isChecked = _param2;
												if (_isChecked) {
															data.edit().putString("adblock", "true").commit();
							FancyToast.makeText(WebActivity.this, "Ad blocker will be added soon!", FancyToast.LENGTH_LONG, FancyToast.ERROR, false).show();
												}
												else {
															data.edit().putString("adblock", "false").commit();
												}
									}
						});
				if (data.getString("desktop", "").equals("true")) {
					check1.setChecked(true);
				}
				else {
					check1.setChecked(false);
				}
				if (data.getString("adblock", "").equals("true")) {
					check2.setChecked(true);
				}
				else {
					check2.setChecked(false);
				}
				line4.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						intent.setClass(getApplicationContext(), HistoryActivity.class);
						startActivity(intent);
						overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
						finish();
					}
				});
				line9.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						if (data.getString("desktop", "").equals("true")) {
							check1.setChecked(false);
						}
						else {
							check1.setChecked(true);
						}
					}
				});
				line10.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						if (data.getString("adblock", "").equals("true")) {
							check2.setChecked(false);
						}
						else {
							check2.setChecked(true);
						}
					}
				});
				line11.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						intent.setAction(Intent.ACTION_SEND);
						intent.putExtra(Intent.EXTRA_TEXT, webview1.getUrl());
						intent.setType("text/plain");
						startActivity(Intent.createChooser(intent, "Share with"));
					}
				});
				line6.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						intent.setClass(getApplicationContext(), CreditsActivity.class);
						startActivity(intent);
						overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
						finish();
					}
				});
				line8.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						TastyToast.makeText(getApplicationContext(), "This function will be added soon!", TastyToast.LENGTH_LONG, TastyToast.ERROR);
						pop_up.dismiss();
					}
				});
				line5.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						TastyToast.makeText(getApplicationContext(), "This function will be added soon!", TastyToast.LENGTH_LONG, TastyToast.ERROR);
						pop_up.dismiss();
					}
				});
				img1.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						pop_up.dismiss();
					}
				});
				img2.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						SketchwareUtil.showMessage(getApplicationContext(), "soon!");
					}
				});
				img3.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						webview1.loadUrl(webview1.getUrl());
						pop_up.dismiss();
					}
				});
				pop_up.showAsDropDown(_view, 0,0);
			}
		});
		
		textview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				TastyToast.makeText(getApplicationContext(), "Tab function will be added soon!", TastyToast.LENGTH_LONG, TastyToast.ERROR);
			}
		});
		
		webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				textview2.setText(_url);
				progressBar.setVisibility(View.VISIBLE);
				try{
					java.net.URL url = new java.net.URL(_url);
					domain = url.getHost();
				}catch (java.net.MalformedURLException e){}
				map = new HashMap<>();
				map.put("url", _url);
				map.put("domain", domain);
				history.add(map);
				sp.edit().putString("history", new Gson().toJson(history)).commit();
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				progressBar.setVisibility(View.GONE);
				super.onPageFinished(_param1, _param2);
			}
		});
		
		textview6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.putExtra("quarry", searchFor);
				intent.setClass(getApplicationContext(), WebActivity.class);
				startActivity(intent);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
				finish();
			}
		});
		
		textview5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finishAffinity();
			}
		});
		
		textview8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), HomeActivity.class);
				startActivity(intent);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
				finish();
			}
		});
		
		textview9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), HistoryActivity.class);
				startActivity(intent);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
				finish();
			}
		});
		
		textview10.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), CreditsActivity.class);
				startActivity(intent);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
				finish();
			}
		});
		
		_req_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				webview1.setVisibility(View.VISIBLE);
				linear6.setVisibility(View.GONE);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				webview1.setVisibility(View.GONE);
				linear6.setVisibility(View.VISIBLE);
			}
		};
	}
	
	private void initializeLogic() {
		_StatusBar_Change_TextColor(linear1, "#FFFFFF");
		_RippleEffect("#BDBDBD", imageview1);
		_RippleEffect("#BDBDBD", linear3);
		_RippleEffect("#BDBDBD", imageview3);
		_RippleEffect("#BDBDBD", linear4);
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/productsansregular.ttf"), 0);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/opensansmedium.ttf"), 0);
		textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/opensansmedium.ttf"), 0);
		textview5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/productsansregular.ttf"), 0);
		textview6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/productsansregular.ttf"), 0);
		textview7.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/opensansmedium.ttf"), 0);
		textview8.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/productsansregular.ttf"), 0);
		textview9.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/productsansregular.ttf"), 0);
		textview10.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/productsansregular.ttf"), 0);
		linear6.setVisibility(View.GONE);
		req.startRequestNetwork(RequestNetworkController.GET, "https://www.google.com/", "A", _req_request_listener);
		int[] colorsCRNXX = { Color.parseColor("#F3F6FB"), Color.parseColor("#F3F6FB") }; android.graphics.drawable.GradientDrawable CRNXX = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNXX);
		CRNXX.setCornerRadii(new float[]{(int)360,(int)360,(int)360,(int)360,(int)360,(int)360,(int)360,(int)360});
		CRNXX.setStroke((int) 0, Color.parseColor("#000000"));
		linear3.setElevation((float) 0);
		linear3.setBackground(CRNXX);
		
		//Paste this code in (add source directly block) asd block
		//Milz
		int[] colorsCRNSF = { Color.parseColor("#ffffff"), Color.parseColor("#ffffff") }; android.graphics.drawable.GradientDrawable CRNSF = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNSF);
		CRNSF.setCornerRadii(new float[]{(int)15,(int)15,(int)15,(int)15,(int)15,(int)15,(int)15,(int)15});
		CRNSF.setStroke((int) 0, Color.parseColor("#000000"));
		linear8.setElevation((float) 5);
		linear8.setBackground(CRNSF);
		
		//Paste this code in (add source directly block) asd block
		//Milz
		int[] colorsCRNLO = { Color.parseColor("#ffffff"), Color.parseColor("#ffffff") }; android.graphics.drawable.GradientDrawable CRNLO = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNLO);
		CRNLO.setCornerRadii(new float[]{(int)15,(int)15,(int)15,(int)15,(int)15,(int)15,(int)15,(int)15});
		CRNLO.setStroke((int) 0, Color.parseColor("#000000"));
		linear11.setElevation((float) 5);
		linear11.setBackground(CRNLO);
		
		//Paste this code in (add source directly block) asd block
		//Milz
		linear2.setElevation((float) 3);
		if (getIntent().hasExtra("quarry")) {
			searchFor = getIntent().getStringExtra("quarry");
		}
		_download_to("/Download/");
		if (getIntent().hasExtra("url")) {
			webview1.loadUrl(getIntent().getStringExtra("url"));
		}
		else {
			if(URLUtil.isValidUrl(searchFor)){
				webview1.loadUrl(searchFor);
			} else {
				webview1.loadUrl("https://www.google.com/search?q=".concat(searchFor));
			}
			webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
		}
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.setWebChromeClient(new WebChromeClient() {
			public void onProgressChanged(WebView view, int progress) {
				progressBar.setProgress(progress);
			}});
		webview1.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
		webview1.getSettings().setDomStorageEnabled(true);
		if (!sp.getString("history", "").equals("")) {
			history = new Gson().fromJson(sp.getString("history", ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		}
		if (data.getString("desktop", "").equals("true")) {
			webview1.getSettings().setLoadWithOverviewMode(true); 
			webview1.getSettings().setUseWideViewPort(true); 
			final WebSettings webSettings = webview1.getSettings(); 
			final String newUserAgent; newUserAgent = "Mozilla/7.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.64 Safari/537.36"; 
			webSettings.setUserAgentString(newUserAgent);
			webview1.getSettings().setBuiltInZoomControls(true);
			webview1.getSettings().setDisplayZoomControls(false);
		}
	}
	
	@Override
	public void onBackPressed() {
		if (webview1.canGoBack()) {
			webview1.goBack();
		}
		else {
			intent.setClass(getApplicationContext(), HomeActivity.class);
			startActivity(intent);
			overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
			finish();
		}
	}
	public void _StatusBar_Change_TextColor(final View _linear, final String _color) {
		try{
			
			_linear.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
			Window w = this.getWindow();w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(Color.parseColor(_color));
			
		}catch (Exception ex) {
			
		}finally{
			
		}
	}
	
	
	public void _RippleEffect(final String _color, final View _view) {
		android.content.res.ColorStateList clr = new android.content.res.ColorStateList(new int[][]{new int[]{}},new int[]{Color.parseColor(_color)});
		android.graphics.drawable.RippleDrawable ripdr = new android.graphics.drawable.RippleDrawable(clr, null, null);
		_view.setBackground(ripdr);
	}
	
	
	public void _download_to(final String _path) {
		webview1.setDownloadListener(new DownloadListener() {
			public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
				DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
				String cookies = CookieManager.getInstance().getCookie(url);
				request.addRequestHeader("cookie", cookies);
				request.addRequestHeader("User-Agent", userAgent);
				request.setDescription("Downloading file...");
				request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimetype));
				request.allowScanningByMediaScanner(); request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
				
				java.io.File aatv = new java.io.File(Environment.getExternalStorageDirectory().getPath() + "codesinsourav");
				
				if(!aatv.exists()){if (!aatv.mkdirs()){ Log.e("TravellerLog ::","Problem creating Image folder");}} request.setDestinationInExternalPublicDir(_path, URLUtil.guessFileName(url, contentDisposition, mimetype));
				
				DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
				manager.enqueue(request);
				showMessage("Downloading File....");
				//Notif if success
				BroadcastReceiver onComplete = new BroadcastReceiver() {
					public void onReceive(Context ctxt, Intent intent) {
						//Code generated by App Designer
						{
							int notifyId = SketchwareUtil.getRandom((int)(0), (int)(99999));
							NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
							Notification.Builder mbuilder = new Notification.Builder(WebActivity.this);
							mbuilder.setSmallIcon(R.drawable.ic_checked);
							mbuilder.setContentTitle("Downloaded successfully");
							mbuilder.setContentText("Your file is downloaded successfully!");
							mbuilder.setShowWhen(true);
							mbuilder.setDefaults( Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE);
							mbuilder.setOngoing(false);
							mbuilder.setColor(Color.parseColor("#2196F3"));
							if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
										String channelId1 = "notifications";
										String channelName1 = "Notifications";
										NotificationChannel channel = new NotificationChannel(channelId1, channelName1, NotificationManager.IMPORTANCE_DEFAULT);
										channel.enableLights(true);
										channel.setLightColor(Color.BLUE);
										channel.setShowBadge(true);
										channel.enableVibration(true);
										mbuilder.setChannelId(channelId1);
										if (mNotificationManager != null) {
													mNotificationManager.createNotificationChannel(channel);
										}
							} else {
										mbuilder.setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_LIGHTS | Notification.DEFAULT_VIBRATE);
							}
							if (mNotificationManager != null) {
										mNotificationManager.notify(notifyId, mbuilder.build());
							}
						}
						unregisterReceiver(this);
					}};
				registerReceiver(onComplete, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
			}
		});
	}
	
	
	public void _Checkbox_ChangeColor(final CheckBox _checkbox, final String _color) {
		_checkbox.getButtonDrawable().setColorFilter(Color.parseColor(_color), PorterDuff.Mode.SRC_IN);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}